from django.shortcuts import render
from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
import json
from .models import Location

def index(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            name = data.get('name')
            latitude = data.get('lat')
            longitude = data.get('lon')

            if name and latitude and longitude:
                location = Location(name=name, latitude=latitude, longitude=longitude)
                location.save()
                return render(request, 'mapitas.html', {"info": 'Ubicación guardada correctamente'})
            else:
                return render(request, 'mapitas.html', {"info": 'Datos incompletos'})
        except Exception as e:
            return render(request, 'mapitas.html', {"info": str(e)})
    else:
        return render(request, 'mapitas.html')

def ubicacion(request):
    return render(request, 'ubicaciones.html')

@csrf_exempt  # Deshabilita CSRF para pruebas (en producción, usa tokens CSRF)
def guardar_ubicacion(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            name = data.get('name')
            latitude = data.get('lat')
            longitude = data.get('lon')

            if name and latitude and longitude:
                location = Location(name=name, latitude=latitude, longitude=longitude)
                location.save()
                return JsonResponse({'message': 'Ubicación guardada correctamente'}, status=201)
            else:
                return JsonResponse({'error': 'Datos incompletos'}, status=400)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=500)
    
    return JsonResponse({'error': 'Método no permitido'}, status=405)

def listar_ubicaciones(request):
    locations = Location.objects.all().values('name', 'latitude', 'longitude')
    return JsonResponse(list(locations), safe=False)
